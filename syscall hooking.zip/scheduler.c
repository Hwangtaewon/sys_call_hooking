
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/desc.h>
#include <asm/pgtable.h>
#include <asm/current.h>
#include <linux/sched.h>
#include <linux/highmem.h>
#include <linux/preempt.h>
#include <asm/topology.h>
#include <linux/kthread.h>
#include <linux/kernel_stat.h>
#include <linux/percpu-defs.h>
#include <linux/smp.h>
#include <linux/delay.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/kallsyms.h>

struct OurTask
{
	int (*fp)(void);
	struct OurTask *next;
};
struct OurTask TaskForce;

EXPORT_SYMBOL(TaskForce);

struct mini_elf_header
{
	uint32_t codeoff;
	uint32_t codesize;
	uint32_t relnum;
};



//------------190115 ���� �κ�---------------------
struct mini_elf_rel
{

	uint32_t reloff;
	
	//function name offset
	uint32_t sym_nameoff;

	//local function offset
	uint32_t sym_value;

	//flag
	//  0x1 : kernel function
	//  0x2 : local function
	uint32_t flag; 
};
#define KERNELFUNC 	0x1
#define LOCALFUNC 	0x2



void * relocate_mini_elf(void * fp)
{
	struct mini_elf_header * header = (struct mini_elf_header *)fp;
	int i;
	
	//relocate
	if(header->relnum > 0)
	{
		struct mini_elf_rel * rel = (struct mini_elf_rel * )((void *)header + 12);

		for(i =0; i< header->relnum; i++)
		{
			void * addr;

			if(rel->flag == KERNELFUNC)
			{
				addr = kallsyms_lookup_name((char *)(fp + rel->sym_nameoff));
			}
			
			else if (rel->flag == LOCALFUNC)
			{
				addr = (void *)(fp + rel->sym_value);
			}

			*(uint64_t *)(fp + rel->reloff) = addr;
			rel ++;
			
		}

	}
	
	return (void *)(fp + header->codeoff);

}
//____________________190115 ���� �κ�_________________



int thread1(void *data)
{
	struct OurTask *temp;
	int res=0;
	int (*fp)(void);

	TaskForce.next = NULL;
	TaskForce.fp =NULL;	
	
	printk("scheduler is running...\n");

	while(1)
	{	
		
		if(TaskForce.next == NULL)
		{
			schedule();
			continue;
		}
		
		msleep(5000);
		printk("new task is detected\n");
		

		//decryption
		fp = TaskForce.next->fp;
		int i;
		for(i=0; i<2048; i++)
		{
			*(char *)fp -= 2;
			fp ++;	
		}

		//relocation		
		fp = (int (*)(void))relocate_mini_elf((void *)TaskForce.next->fp);
		
		fp();

		temp = TaskForce.next;
		TaskForce.next = TaskForce.next->next;	
		


		//------------190115 ���� �κ�---------------------
		//vfree(temp->fp); //����
		//_____________190115 ���� �κ�_________________


		temp->fp = NULL;	
		kfree(temp);
		temp = NULL;

	}
	return 0;
}

static int hello_init(void)
{
	struct task_struct *task1;

	task1 = kthread_create(thread1,NULL,"task1");
	wake_up_process(task1);

	return 0;
}


static void hello_exit(void)
{

	printk("end module\n=========================================================\n");

}


module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("Dual BSD/GPL");



